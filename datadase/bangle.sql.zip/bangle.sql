-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 04, 2021 at 04:43 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bangle`
--

-- --------------------------------------------------------

--
-- Table structure for table `bill_details`
--

CREATE TABLE `bill_details` (
  `bill_details_id` int(11) NOT NULL auto_increment,
  `bill_master_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `rate` double NOT NULL,
  `discount` double NOT NULL,
  PRIMARY KEY  (`bill_details_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `bill_details`
--

INSERT INTO `bill_details` (`bill_details_id`, `bill_master_id`, `product_id`, `quantity`, `rate`, `discount`) VALUES
(1, 1, 1, 11, 786, 100),
(2, 2, 1, 20, 300, 0),
(3, 3, 5, 500, 12, 0),
(4, 3, 6, 100, 15, 0),
(5, 4, 10, 15, 50, 0);

-- --------------------------------------------------------

--
-- Table structure for table `bill_master`
--

CREATE TABLE `bill_master` (
  `bill_master_id` int(11) NOT NULL auto_increment,
  `bill_date` date NOT NULL,
  `customer_id` int(11) NOT NULL,
  `other_charges` double NOT NULL,
  PRIMARY KEY  (`bill_master_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `bill_master`
--

INSERT INTO `bill_master` (`bill_master_id`, `bill_date`, `customer_id`, `other_charges`) VALUES
(1, '2021-08-01', 4, 0),
(2, '2021-08-02', 1, 0),
(3, '2021-08-04', 5, 0),
(4, '2021-08-04', 12, 0);

-- --------------------------------------------------------

--
-- Table structure for table `customer_details`
--

CREATE TABLE `customer_details` (
  `customer_id` int(11) NOT NULL auto_increment,
  `customer_name` varchar(50) NOT NULL,
  `customer_address` varchar(200) NOT NULL,
  `customer_city` varchar(50) NOT NULL,
  `contact_no` bigint(12) NOT NULL,
  `email_id` varchar(100) NOT NULL,
  `customer_code` varchar(50) NOT NULL,
  PRIMARY KEY  (`customer_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `customer_details`
--

INSERT INTO `customer_details` (`customer_id`, `customer_name`, `customer_address`, `customer_city`, `contact_no`, `email_id`, `customer_code`) VALUES
(2, 'Ravi', 'dharwad', 'dharwad', 6363094880, 'ravi@gmail.com', 'CUST2'),
(3, 'Ravi', 'Y S Colony ', 'Dharwad', 9343182925, 'ravi@gmail.com', 'CUST3'),
(4, 'Ravi', 'Y S Colony ', 'Dharwad', 9343182925, 'ravi@gmail.com', 'CUST4'),
(5, 'ramesh g', 'Y S colony', 'Dharwad', 4637323236, 'poojayaligar99@gmail.com', 'CUST5'),
(11, 'pooja', 'vidyagiri', 'belgavi', 9999999786, 'poojay@gmail.com', 'CUST6'),
(12, 'prasad', 'belgavi', 'karnataka', 9844096394, 'prasad@gmail.com', 'CUST12');

-- --------------------------------------------------------

--
-- Table structure for table `customer_order_details`
--

CREATE TABLE `customer_order_details` (
  `customer_order_details_id` int(11) NOT NULL auto_increment,
  `customer_order_master_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `cust_order_status` varchar(50) NOT NULL,
  PRIMARY KEY  (`customer_order_details_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `customer_order_details`
--

INSERT INTO `customer_order_details` (`customer_order_details_id`, `customer_order_master_id`, `product_id`, `quantity`, `cust_order_status`) VALUES
(1, 1, 1, 11, 'Confirmed'),
(2, 2, 2, 15, 'Pending'),
(3, 3, 4, 500, 'Confirmed'),
(4, 4, 5, 15, 'Pending'),
(5, 5, 5, 15, 'Confirmed'),
(6, 6, 4, 56, 'No Stock'),
(7, 6, 5, 100, 'No Stock'),
(8, 7, 4, 15, 'Pending'),
(11, 8, 6, 15, 'Confirmed'),
(12, 9, 4, 45, 'Pending'),
(13, 9, 6, 30, 'Pending'),
(14, 9, 5, 56, 'Pending'),
(15, 9, 8, 78, 'Pending'),
(16, 10, 6, 67, 'Pending'),
(18, 11, 10, 15, 'Confirmed');

-- --------------------------------------------------------

--
-- Table structure for table `customer_order_master`
--

CREATE TABLE `customer_order_master` (
  `customer_order_master_id` int(11) NOT NULL auto_increment,
  `date` date NOT NULL,
  `customer_id` int(11) NOT NULL,
  PRIMARY KEY  (`customer_order_master_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `customer_order_master`
--

INSERT INTO `customer_order_master` (`customer_order_master_id`, `date`, `customer_id`) VALUES
(1, '2021-08-01', 4),
(2, '2021-08-03', 5),
(3, '2021-08-03', 5),
(5, '2021-08-03', 5),
(6, '2021-08-03', 3),
(7, '2021-08-03', 3),
(8, '2021-08-03', 5),
(9, '2021-08-04', 5),
(10, '2021-08-04', 5),
(11, '2021-08-04', 12);

-- --------------------------------------------------------

--
-- Table structure for table `customer_receipts`
--

CREATE TABLE `customer_receipts` (
  `customer_receipts_id` int(11) NOT NULL auto_increment,
  `customer_id` int(11) NOT NULL,
  `amount` double NOT NULL,
  `narration` varchar(500) NOT NULL,
  `Date` date NOT NULL,
  PRIMARY KEY  (`customer_receipts_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `customer_receipts`
--

INSERT INTO `customer_receipts` (`customer_receipts_id`, `customer_id`, `amount`, `narration`, `Date`) VALUES
(1, 2, 6000, 'advance', '2021-08-01'),
(2, 1, 1000, 'advance', '2021-08-03'),
(3, 5, 8000, 'bill amount', '2021-08-04'),
(4, 12, 864, 'full paid bill amount', '2021-08-04');

-- --------------------------------------------------------

--
-- Table structure for table `expenditure`
--

CREATE TABLE `expenditure` (
  `expenditure_id` int(11) NOT NULL auto_increment,
  `expenditure_name` varchar(200) NOT NULL,
  `description` varchar(500) NOT NULL,
  `total_amount` double NOT NULL,
  `given_to` varchar(100) NOT NULL,
  `voucher_no` varchar(50) NOT NULL,
  `given_date` date NOT NULL,
  PRIMARY KEY  (`expenditure_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `expenditure`
--


-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `hint_q` varchar(100) NOT NULL,
  `hint_a` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`username`, `password`, `type`, `hint_q`, `hint_a`, `status`) VALUES
('admin', '321', 'admin', 'who_r_u', 'admin', 'active'),
('V20211', 'V20211', 'vendor', 'Enter Contact No', '6363094850', 'Active'),
('V20212', 'V20212', 'vendor', 'Enter Contact No', '9343182925', 'Active'),
('CUST1', 'CUST1', 'customer', 'Enter Your Contact No', '7543928907', 'Active'),
('CUST2', 'CUST2', 'customer', 'Enter Your Contact No', '6363094889', 'Active'),
('CUST3', 'ravi', 'user', 'What is your Email-id', 'ravi@gmail.com', 'active'),
('CUST4', '123', 'user', 'What is your Email-id', 'ravi@gmail.com', 'active'),
('V20213', 'V20213', 'vendor', 'Enter Contact No', '2345876546', 'Active'),
('CUST5', 'pavan111', 'user', 'What is your Email-id', 'pavan@gmail.com', 'active'),
('V20214', 'V20214', 'vendor', 'Enter Contact No', '9897654321', 'Active'),
('V20215', 'V20215', 'vendor', 'Enter Contact No', '9876545679', 'Active'),
('CUST6', 'CUST6', 'user', 'Enter Your Contact No', '9999999786', 'Active'),
('CUST12', 'prasad149', 'user', 'What is your Email-id', 'prasad@gmail.com', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `production`
--

CREATE TABLE `production` (
  `production_id` int(11) NOT NULL auto_increment,
  `product_id` int(11) NOT NULL,
  `total_production` double NOT NULL,
  `description` varchar(500) NOT NULL,
  `production_date` date NOT NULL,
  PRIMARY KEY  (`production_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `production`
--

INSERT INTO `production` (`production_id`, `product_id`, `total_production`, `description`, `production_date`) VALUES
(1, 1, 6000, 'best quality', '2021-08-01'),
(2, 4, 1000, 'green colored', '2021-08-03'),
(3, 5, 4000, 'red colored', '2021-08-06'),
(4, 6, 460, 'colored', '2021-08-03'),
(5, 10, 1000, 'green colored', '2021-08-04');

-- --------------------------------------------------------

--
-- Table structure for table `product_category`
--

CREATE TABLE `product_category` (
  `product_category_id` int(11) NOT NULL auto_increment,
  `product_category_name` varchar(100) NOT NULL,
  PRIMARY KEY  (`product_category_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `product_category`
--

INSERT INTO `product_category` (`product_category_id`, `product_category_name`) VALUES
(1, 'Green Color Glass'),
(2, 'Red color glass'),
(4, 'Designer '),
(5, 'Designer '),
(7, 'new wedding bangles');

-- --------------------------------------------------------

--
-- Table structure for table `product_details`
--

CREATE TABLE `product_details` (
  `product_id` int(11) NOT NULL auto_increment,
  `product_category_id` int(11) NOT NULL,
  `product_name` varchar(50) NOT NULL,
  `product_size` varchar(100) NOT NULL,
  `product_type` varchar(100) NOT NULL,
  `product_description` varchar(200) NOT NULL,
  `product_image` varchar(500) NOT NULL,
  `product_price` double NOT NULL,
  PRIMARY KEY  (`product_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `product_details`
--

INSERT INTO `product_details` (`product_id`, `product_category_id`, `product_name`, `product_size`, `product_type`, `product_description`, `product_image`, `product_price`) VALUES
(5, 4, 'Designer bangle', '8', 'designed', 'coloured designed', 'bangle1.jpeg', 4000),
(6, 1, 'color bangle', '10', 'designed', '200 dozen ', 'banglestock3.jpg', 3000),
(7, 6, 'golden bangles', '8', 'designed', '130 dozen', 'goldenbangle2.jpg', 6000),
(8, 5, 'red bangles', '78', 'designed', '400 dozen', 'redglass.jpg', 3000),
(9, 1, 'plain glass bangles', '5', 'plain', '200 dozen ', 'imagebangle.jpg', 600),
(10, 7, 'wedding bangles', '10', 'glass+shiny', 'wedding bangles 1000 dozen', 'bangle.jpg', 5000);

-- --------------------------------------------------------

--
-- Table structure for table `raw_material_details`
--

CREATE TABLE `raw_material_details` (
  `raw_material_id` int(11) NOT NULL auto_increment,
  `raw_material_name` varchar(100) NOT NULL,
  `raw_material_description` varchar(500) NOT NULL,
  PRIMARY KEY  (`raw_material_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `raw_material_details`
--

INSERT INTO `raw_material_details` (`raw_material_id`, `raw_material_name`, `raw_material_description`) VALUES
(1, 'silica', 'Liquid forms'),
(2, ' raw glass', 'liquid  form'),
(3, 'broken glass', 'solid form');

-- --------------------------------------------------------

--
-- Table structure for table `raw_material_purchase`
--

CREATE TABLE `raw_material_purchase` (
  `raw_material_purchase_id` int(11) NOT NULL auto_increment,
  `vendor_id` int(11) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY  (`raw_material_purchase_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `raw_material_purchase`
--

INSERT INTO `raw_material_purchase` (`raw_material_purchase_id`, `vendor_id`, `date`) VALUES
(1, 1, '2021-08-01'),
(2, 2, '2021-08-03'),
(3, 1, '2021-08-03'),
(4, 3, '2021-08-03'),
(5, 5, '2021-08-04');

-- --------------------------------------------------------

--
-- Table structure for table `raw_material_purchase_details`
--

CREATE TABLE `raw_material_purchase_details` (
  `raw_material_purchase_details_id` int(11) NOT NULL auto_increment,
  `raw_material_purchase_id` int(11) NOT NULL,
  `raw_material_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `rate` double NOT NULL,
  `discount` double NOT NULL,
  PRIMARY KEY  (`raw_material_purchase_details_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `raw_material_purchase_details`
--

INSERT INTO `raw_material_purchase_details` (`raw_material_purchase_details_id`, `raw_material_purchase_id`, `raw_material_id`, `quantity`, `rate`, `discount`) VALUES
(1, 1, 1, 11, 786, 0),
(2, 2, 2, 100, 12, 0),
(3, 3, 2, 130, 500, 10),
(4, 3, 3, 200, 3000, 0),
(5, 3, 2, 25, 450, 0),
(6, 3, 1, 12, 267, 0),
(7, 4, 2, 20, 34, 200),
(8, 5, 1, 15, 10, 0),
(9, 5, 2, 20, 500, 0);

-- --------------------------------------------------------

--
-- Table structure for table `stock_details`
--

CREATE TABLE `stock_details` (
  `stock_id` int(11) NOT NULL auto_increment,
  `product_id` int(11) NOT NULL,
  `stock` int(11) NOT NULL,
  PRIMARY KEY  (`stock_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `stock_details`
--

INSERT INTO `stock_details` (`stock_id`, `product_id`, `stock`) VALUES
(1, 1, 5969),
(2, 4, 1000),
(3, 7, 600),
(4, 6, 360),
(5, 10, 985);

-- --------------------------------------------------------

--
-- Table structure for table `vendor_details`
--

CREATE TABLE `vendor_details` (
  `vendor_id` int(11) NOT NULL auto_increment,
  `vendor_name` varchar(50) NOT NULL,
  `vendor_address` varchar(200) NOT NULL,
  `vendor_city` varchar(20) NOT NULL,
  `contact_no` varchar(12) NOT NULL,
  `email_id` varchar(50) NOT NULL,
  `vendor_code` varchar(50) NOT NULL,
  `gst_no` varchar(100) NOT NULL,
  PRIMARY KEY  (`vendor_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `vendor_details`
--

INSERT INTO `vendor_details` (`vendor_id`, `vendor_name`, `vendor_address`, `vendor_city`, `contact_no`, `email_id`, `vendor_code`, `gst_no`) VALUES
(1, 'Ganesh', 'Y S Colony Dharwad', 'Dharwad dwd', '6363094850', 'ganesh@gmail.com', 'V20211', '9898989'),
(2, 'Ramesh', 'Gandhinagar Belgaum', 'Belgavi', '9343182925', 'ramesh@gmail.com', 'V20212', '456786'),
(4, 'surya', 'vidyagiri', 'dharwad', '9897654321', 'surya@gmail.com', 'V20214', '9988776655'),
(5, 'pallavi', 'Y S Colony ', 'Dharwad', '9876545679', 'pallavim@gmail.com', 'V20215', '786786');

-- --------------------------------------------------------

--
-- Table structure for table `vendor_payment`
--

CREATE TABLE `vendor_payment` (
  `vendor_payment_id` int(11) NOT NULL auto_increment,
  `vendor_id` int(11) NOT NULL,
  `amount` double NOT NULL,
  `narration` varchar(500) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY  (`vendor_payment_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `vendor_payment`
--

INSERT INTO `vendor_payment` (`vendor_payment_id`, `vendor_id`, `amount`, `narration`, `date`) VALUES
(1, 1, 5000, 'Full payment', '2021-08-01'),
(2, 2, 5000, 'Full payment', '2021-06-02'),
(3, 2, 4888, 'full paid', '2021-08-03'),
(4, 1, 5000, 'full paid', '2021-08-03'),
(5, 3, 10, 'advance', '2021-08-04'),
(6, 4, 5000, 'full paid', '2021-08-04');
